<?php
// Text
$_['text_title'] = 'Visa/Mastercard';
$_['text_wait'] = 'Please wait!';

