<?php
// Text
$_['text_title'] = 'Sofort Banking';
$_['text_wait'] = 'Even geduld a.u.b.';

// Entry
$_['entry_bank_id'] = 'Kies je land';
