<?php
// Text
$_['text_title'] = 'GIP';
$_['text_wait'] = 'Even geduld a.u.b.';