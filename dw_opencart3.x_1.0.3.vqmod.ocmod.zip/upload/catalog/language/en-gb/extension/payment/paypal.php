<?php
// Text
$_['text_title'] = 'Paypal';
$_['text_wait'] = 'Please wait!';