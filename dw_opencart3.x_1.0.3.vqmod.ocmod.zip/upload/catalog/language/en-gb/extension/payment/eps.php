<?php
// Text
$_['text_title'] = 'EPS';
$_['text_wait'] = 'Please wait!';