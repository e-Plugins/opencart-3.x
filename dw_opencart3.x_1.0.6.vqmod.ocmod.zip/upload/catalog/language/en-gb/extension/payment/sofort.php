<?php
// Text
$_['text_title'] = 'Sofort';
$_['text_wait'] = 'Please wait!';

// Entry
$_['entry_bank_id'] = 'Country';

